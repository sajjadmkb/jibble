﻿using System;
using System.Linq;
using Jibble.Data.Models;
using Microsoft.OData.Client;


namespace Jibble.Data
{
    public class JibbleClient
    {
        private readonly DataServiceContext _context;

        public JibbleClient(string serviceUrl)
        {
            _context = new DataServiceContext(new Uri(serviceUrl));
        }

        public Person GetPersonById(int employeeId)
        {
            Person? p = _context.CreateQuery<Person>($"Employees/{employeeId}").FirstOrDefault();
            return p;
        }

        public IQueryable<Person> GetPeople()
        {
            return _context.CreateQuery<Person>("Employees");
        }
    }
}
