﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jibble
{
    internal class Constants
    {
        public const string ODataApiUrl = "https://services.odata.org/V4/OData/OData.svc/";
    }
}
